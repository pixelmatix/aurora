{
  "text":"Aurora: now with 100% more JSON! (JavaScript Object Notation)",
  "blue":255,
  "top":19,
  "font":"font6x10",
  "speed":65,
  "mode":"wrapForwardFromLeft"
}